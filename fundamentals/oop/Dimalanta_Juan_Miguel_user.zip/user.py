#creating the user class
class user:
    def __init__(self):
        self.name = "Miguel"
        self.email = "miguel@gmail.com"
        self.account_balance = 0
#adding the deposit method to the user class
    def make_deposit(self, amount):
        self.account_balance += amount
        print(self.account_balance)
    #adding the check balance method
    def checkBalance(self):
        print (self.account_balance)
    #adding withdraw method
    def make_withdrawal(self, amount):
        self.account_balance -= amount
        print(self.account_balance)
    #adding the transfer_money method
    def transfer_money(self, user, amount):
        self.account_balance -= amount
        user.account_balance += amount
        print(self.account_balance)
        print(user.account_balance)

#created 3 instances of the user class
user()
don = user()
charles = user()
marge = user()

don.name = "Don"
charles.name = "Charles"
marge.name = "Marge"

#user1 making 3 deposits and 1 withdrawal
don.make_deposit(500)
don.make_deposit(200)
don.make_withdrawal(150)

#user2 making 2 deposits and 2 withdrawals
charles.make_deposit(5000)
charles.make_deposit(15000)
charles.make_withdrawal(200)
charles.make_withdrawal(150)

#user3 making 1 deposit and 3 withdrawals
marge.make_deposit(500000)
marge.make_withdrawal(20)
marge.make_withdrawal(60)
marge.make_withdrawal(10000)

#user 1 transfers money to user3
don.transfer_money(marge, 100)