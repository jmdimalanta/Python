from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
import re

class Pie():
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.filling = data['filling']
        self.crust = data['crust']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.votes = data['votes']
        self.user_id = data['user_id']

    def add_vote(self,votes):
        self.votes += 1
        return self

    @classmethod
    def get_all_pies(cls):
        query = 'SELECT * FROM pies LEFT JOIN users ON pies.user_id = users.id;'
        print(query)
        return connectToMySQL('pypie').query_db(query)

    @classmethod
    def get_all_users_pies(cls, data):
        query = 'SELECT * FROM pies WHERE id = %(id)s;'
        results = connectToMySQL('pypie').query_db(query,data)
        print (results)
        return cls(results)

    @classmethod
    def get_users_pie(cls,data):
        query = 'SELECT * FROM pies WHERE id = %(id)s;'
        results = connectToMySQL('pypie').query_db(query,data)
        print (results)
        return cls(results[0])

    @classmethod
    def create_pie(cls, form_data):
        query = 'INSERT INTO pies (name, filling, crust, user_id) VALUES(%(name)s, %(filling)s, %(crust)s, %(user_id)s)'
        return connectToMySQL('pypie').query_db(query, form_data)

    @classmethod
    def update_pie(cls, form_data):
        query = 'UPDATE pies SET name = %(name)s, filling = %(filling)s, crust = %(crust)s WHERE id = %(id)s'
        return connectToMySQL('pypie').query_db(query, form_data)

    @classmethod
    def add_vote(cls, data):
        query = 'UPDATE pies SET votes = votes + 1 WHERE id = %(id)s'
        return connectToMySQL('pypie').query_db(query, data)
    
    @classmethod
    def destroy(cls, data):
        query = 'DELETE FROM pies WHERE id = %(id)s'
        return connectToMySQL('pypie').query_db(query, data)

    @staticmethod
    def pie_validator(data):
        is_valid = True
        if len(data['name']) < 3:
            flash("Name must be at least 3 characters")
            is_valid = False
        query = "SELECT * FROM pies WHERE name = %(name)s"
        results = connectToMySQL('pypie').query_db(query,data)
        if len(results) != 0:
            flash('PyPie already exists!')
            is_valid = False
        if len(data['filling']) < 3:
            flash("Filling must be at least 3 characters")
            is_valid = False
        if len(data['crust']) < 3:
            flash("Crust must be at least 3 characters")
            is_valid = False
        return is_valid
