from flask_app.models.pypie import Pie
from flask_app import app
from flask import render_template, redirect, request, session

@app.route('/pie_derby')
def pypie_derby():
    return render_template('pie_derby.html', pies = Pie.get_all_pies())

@app.route('/pie/create', methods=['POST'])
def create_pie():
    valid = Pie.pie_validator(request.form)
    if valid:
        data = {
            'name': request.form['name'],
            'filling': request.form['filling'],
            'crust': request.form['crust'],
            'user_id': session['user_id']
        }
        pie = Pie.create_pie(data)
    return redirect('/welcome')

@app.route('/pie/<int:pie_id>/edit')
def edit(pie_id):
    data = {
        'id' : pie_id
    }
    return render_template('edit.html', pie = Pie.get_users_pie(data))

@app.route('/pie/<int:pie_id>/update', methods = ['POST'])
def update_pie(pie_id):
    Pie.update_pie(request.form)
    return redirect('/welcome')

@app.route('/pie/<int:pie_id>/delete')
def destroy(pie_id):
    data = {
        'id' : pie_id
    }
    Pie.destroy(data)
    return redirect('/welcome')

@app.route('/pie/<int:pie_id>/one_pie')
def show_pie(pie_id):
    data = {
        'id' : pie_id
    }
    return render_template('one_pie.html', pie = Pie.get_users_pie(data))

@app.route('/pie/<int:pie_id>/vote')
def one_vote(pie_id):
    data = {
        'id' : pie_id
    }
    Pie.add_vote(data)
    return redirect ('/pie_derby')
