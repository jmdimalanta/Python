from users_cr.controller import users 
from users_cr import app

if __name__=="__main__":
    app.run(debug=True)