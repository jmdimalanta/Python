from flask import Flask, render_template, request, redirect

from users import User

from mysqlconnection import connectToMySQL

app=Flask(__name__)

@app.route('/')
def index():
    return redirect('/users')


@app.route('/users')
def users():
    return render_template("users.html",users=User.get_all())


@app.route('/user/new')
def new():
    return render_template("new_user.html")

@app.route('/user/create',methods=['POST'])
def create():
    print(request.form)
    User.save(request.form)
    return redirect('/users')

@app.route('/show/<int:users_id>')
def detail_page(users_id):
    query = "SELECT * FROM users WHERE users.id = %(id)s;"
    data = {
        'id': users_id
    }
    results = connectToMySQL('users_schema').query_db(query,data)
    return render_template("details_page.html", users = results[0])

@app.route('/edit_page/<int:users_id>')
def edit_page(users_id):
    query = "SELECT FROM * users WHERE id = %(id)s;"
    data = {
        'id' : users_id
    }
    users = connectToMySQL('users_schema').query_db(query, data)
    print(users)
    return render_template("edit_page.html")

@app.route('/update/<int:users_id>', methods = ['POST'])
def update(users_id):
    query = "UPDATE users SET first_name= %(first_name)s, last_name= %(last_name)s, email= %(email)s, updated_at = NOW() WHERE id = %(id)s;"
    data = {
        "id" : users_id,
        "first_name" : request.form['first_name'],
        "last_name" : request.form['last_name'],
        "email" : request.form['email']
    }
    users = connectToMySQL('users_schema').query_db(query, data)
    print(users)
    return redirect(f"/show/{users_id}")

@app.route('/delete/<int:users_id>')
def delete(users_id):
    query = "DELETE FROM users WHERE id = %(id)s;"
    data = {
        'id': users_id,
    }
    connectToMySQL('users_schema').query_db(query, data)
    return redirect('/users')

if __name__=="__main__":
    app.run(debug=True)